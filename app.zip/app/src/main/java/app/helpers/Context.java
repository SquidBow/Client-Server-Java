package app.helpers;

public class Context {

    public NetContext net_context;
    public DBContext db_context;

    Context(NetContext network_context, DBContext database_context) {
        net_context = network_context;
        db_context = database_context;
    }
}
