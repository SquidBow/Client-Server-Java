package app.helpers;

public class DBContext {

    public String table;
    public String order_column = null;
    public boolean order_ascending = false;
    public String[] filters;

    // Пагінація!!!
    public int limit;
    public int offset;

    public DBContext(String table, String[] filters, int limit, int offset) {
        this.table = table;
        this.filters = filters;
        this.limit = limit;
        this.offset = offset;
    }

    public DBContext(
        String table,
        String[] filters,
        int limit,
        int offset,
        String order_column
    ) {
        this(table, filters, limit, offset);
        this.order_column = order_column;
    }

    public DBContext(
        String table,
        String[] filters,
        int limit,
        int offset,
        String order_column,
        boolean order_ascending
    ) {
        this(table, filters, limit, offset, order_column);
        this.order_ascending = order_ascending;
    }
}
