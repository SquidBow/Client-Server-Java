package app.objects;

import app.interfaces.*;
import java.util.Map;

public class Product implements IDBObject {

    public Map<String, Object> product;

    public Product(
        String upc,
        String name,
        int category,
        double price,
        int quantity,
        String manufacturer,
        String characteristics
    ) {
        product.put("upc", upc);
        product.put("name", name);
        product.put("category", category);
        product.put("price", price);
        product.put("quantity", quantity);
        product.put("manufacturer", manufacturer);
        product.put("characteristics", characteristics);
    }

    @Override
    public String getPrimaryKey() {
        return "upc";
    }

    @Override
    public Object getPrimaryValue() {
        return product.get(getPrimaryKey());
    }

    @Override
    public Map<String, Object> getMap() {
        return product;
    }
}
